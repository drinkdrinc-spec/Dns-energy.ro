# DNS Energy — audit inițial și jurnal de modificări

Data verificării: 28.10.2026
Sursă: arhiva `dns-energy-source.zip` atașată în conversație.

## 1. Integritatea sursei

- Arhiva ZIP este accesibilă local și `unzip -t` nu a raportat erori.
- Conține surse `backend/` și `frontend/`, inclusiv documentație, teste și `yarn.lock`.
- Nu a fost găsit un fișier `.env` în arhiva inspectată. Nu au fost exportate secrete sau credențiale.
- Arhiva originală include `node_modules`, cache-uri și `__pycache__`; acestea nu sunt necesare în distribuția sursă curată.

## 2. Funcționalități identificate în sursă

- Backend FastAPI cu MongoDB, autentificare, roluri, profiluri, setări și date pe module.
- Module pentru clienți, prosumator, DI-U, ATR, documente, catalog, personal, instrumente, PRAM, lucrări, putere și proiecte.
- Ofertare/contracte și generare de documente.
- Bibliotecă de documente și generator pentru opisuri.
- Configurator CEF, calcule de dimensionare (`cef.py`, `sizing.py`), generare PDF pentru schema monofilară (`sld.py`, `schema_cef.py`) și editor pentru valori ale schemei (`sld_edit_routes.py`, `SldEditor.jsx`).
- Catalog cu categorii pentru invertor, panou, baterie și smart meter; câmpuri de încărcare fișă tehnică și declarație de conformitate.
- Module de documente ANRE și rute pentru dosare/șabloane.
- Abonamente implicite START 250 lei, PRO 500 lei și FULL 1.000 lei; în `billing_routes.py` există fluxuri pentru facturi/proforme, plăți Stripe, webhook și profil de facturare. Funcționarea end-to-end nu a putut fi confirmată fără baza de date și secretele serviciilor.
- Documente DI-U pentru PRAM separate pe verificarea prizei de pământ, continuitate, izolație și DDR; trebuie verificat dacă experiența de completare respectă cerința unui singur formular complet.

## 3. Cerințe recuperate din istoricul disponibil

1. Datele clientului se introduc o singură dată și se reutilizează în ofertă, contract, dosarele de prosumator și DI-U, documente și scheme.
2. Date de facturare distincte pentru utilizatorii platformei; acces diferențiat pe abonamente și link automat de plată.
3. Abonamente: 250 lei pentru dosar de prosumator cu un singur invertor; 500 lei pentru prosumator și DI-U; 1.000 lei pentru întreaga platformă.
4. Schema monofilară trebuie să fie editabilă, să păstreze valorile salvate și să reprezinte configurația reală, fără valori afișate aiurea.
5. La selectarea unui model de invertor/panou/baterie, parametrii tehnici trebuie preluați și utilizați în calcule, nu doar atașați ca fișe. Utilizatorul nu trebuie să reintroducă manual parametrii care există în fișa modelului; configurarea stringurilor trebuie simplificată.
6. Catalog tehnic căutabil, pentru mai multe mărci și modele, cu fișe tehnice oficiale, declarații UE de conformitate și alte documente aplicabile. Datele/certificatele nu trebuie inventate.
7. Dosare prosumator, ATR, DI-U, documente de racordare, formulare, opisuri, scheme, procese-verbale și documente de punere în funcțiune.
8. Documentație pentru atestarea firmei ANRE, inclusiv opis, cereri și documente tehnice. În istoricul adiacent s-au discutat cerințe C1A/C2A, certificate ONRC recente, organigramă, echipamente, personal/electricieni, dovezi de angajare/servicii, declarații, dovada taxei și semnarea documentelor.
9. Buletin PRAM pentru priza de pământ cu câmpuri complete și valori măsurate; nu trebuie fabricate rezultate de măsurare.
10. Conturi separate pentru instalatori/utilizatori, identificare pe CUI, atestat ANRE încărcat și verificat, semnături și acces separat.
11. Documentele DNS HOSTESS S.R.L. trebuie să poată include datele firmei și atestatul ANRE; în cerințe anterioare s-a cerut păstrarea doar a semnăturii executantului în anumite procese-verbale/constatări.
12. Cerințe conexe de prezență online: dns-energy.ro, pagini SEO distincte pentru servicii, versiune în engleză și atragerea de clienți din România/UE. Acestea țin de site-ul public și trebuie diferențiate de aplicația de dosare.

## 4. Modificări efectuate în această etapă

### Calcule stringuri PV — eliminarea coeficienților de temperatură inventați

Fișier: `backend/cef.py`
- Anterior, calculul folosea implicit coeficientul Voc de `-0,27 %/°C` dacă lipsea din date.
- Anterior, coeficientul Vmp era dedus automat ca `coeficient Voc - 0,08 %/°C`, fără să existe valoarea modelului selectat.
- Acum, `Voc` la rece se calculează numai dacă este disponibil coeficientul Voc; `Vmp` la cald se calculează numai dacă este disponibil coeficientul Vmp.
- Lipsa acestor date produce avertizări explicite, iar verificările dependente nu sunt raportate ca fiind calculate.
- Calculele STC care au parametri disponibili (putere string, Voc/Vmp STC) rămân disponibile.

Fișier: `backend/sizing.py`
- Raportul de dimensionare nu mai prezintă coeficientul Voc implicit ca valoare calculată.
- Include câmp separat pentru coeficientul Vmp și explică atunci când datele lipsesc.
- Nu mai propune o tensiune de separator DC bazată pe o valoare Voc la rece necunoscută.

Fișier: `backend/schema_cef.py`
- Schema poate afișa „Voc la rece: NECONFIRMAT” dacă parametrul nu poate fi calculat, în loc să formateze o valoare lipsă ca și cum ar exista.

Fișiere frontend:
- `frontend/src/pages/EquipmentCatalog.jsx`: adăugate câmpuri de catalog pentru coeficientul de temperatură Vmp, NOCT și coeficientul Pmax al panoului.
- `frontend/src/components/cef/InverterCard.jsx`: la selectarea panoului se preia și Imp, coeficientul Vmp; acestea sunt afișate în configurator.

Test nou: `backend/tests/test_technical_parameter_safety.py` — teste locale, fără rețea, pentru absența coeficienților, utilizarea coeficienților existenți și păstrarea calculelor STC.

## 5. Teste efectuate

- `unzip -t dns-energy-source.zip`: PASS.
- `python -m compileall` pentru fișierele backend modificate: PASS.
- `pytest tests/test_technical_parameter_safety.py`: 3 teste PASS.
- Test de calcul CEF pe eșantionul existent: a rulat și a returnat totalurile așteptate (17,63 kWp, 18 kW invertoare, 30,48 kWh baterii, 38 panouri); avertizările privind coeficienții lipsă sunt acum explicite.
- Parser Babel pentru fișierele JSX modificate: PASS.

## 6. Teste blocate / limitări actuale

- Suita existentă completă este în principal de integrare și cere `REACT_APP_BACKEND_URL`, un backend pornit, MongoDB și date de autentificare; mediul actual nu are URL-ul setat.
- `pytest.ini` cere `pytest-xdist`, care nu este instalat în mediul de verificare. Rularea serială a suitei complete a eșuat la colectare și a raportat și lipsa pachetului `motor`, a pachetului `stripe` și a fișierului `/app/frontend/.env` pentru unele teste.
- `npm run build` nu a putut rula: executabilul Vite din `node_modules` referă un modul lipsă. Fișierele JSX modificate au trecut verificarea sintactică Babel, dar build-ul complet rămâne neconfirmat.
- Nu s-au putut testa plata Stripe, emiterea facturii fiscale SmartBill, autentificarea, salvarea în MongoDB sau fluxurile publicate fără configurațiile serviciilor.

## 7. Lacune care rămân de implementat/verificat

1. Catalog extins cu modele reale, inclusiv invertorul Deye de 100 kW menționat, și parametri validați din fișele oficiale. Seed-ul actual are puține modele și este marcat în cod ca orientativ.
2. Proveniența fiecărui parametru: producător, model/revizie, document-sursă, dată verificare și stare verificată/neconfirmată.
3. Extinderea catalogului la celelalte componente de instalație (protecții, cabluri, SPD, tablouri, aparate de măsură și alte echipamente), nu doar cele patru categorii actuale.
4. Simplificarea configurării stringurilor conform cerinței: introducerea numărului de stringuri și calcularea/validarea celorlalte date în baza fișelor selectate și a configurației reale.
5. Audit end-to-end al schemei monofilare: editare, salvare, recalcul, previzualizare și export PDF; verificarea tuturor valorilor afișate și a propagării între dosar și schemă.
6. Verificarea completă a reutilizării datelor clientului și a datelor de facturare în toate documentele și ofertele.
7. Compararea fiecărui formular/opis ANRE cu cerințele oficiale actuale și confirmarea că nu sunt prezentate șabloane interne ca formulare oficiale.
8. Un flux unificat și complet pentru buletinul prizei de pământ, păstrând distinct rezultatele măsurate ale verificatorului și calculele/propunerile proiectantului.
9. Teste de integrare pentru cele trei planuri, permisiuni, generarea linkului de plată, confirmarea webhook și blocarea modulelor neincluse în abonament.
10. Build frontend complet și suite backend completă într-un mediu cu dependențe și servicii configurate.

## 8. Principiu de siguranță a datelor tehnice

Nicio valoare de măsurare, declarație de conformitate, certificat, aprobare sau dată oficială nu trebuie inventată. Dacă documentația modelului nu furnizează un parametru necesar, aplicația trebuie să marcheze verificarea ca neconfirmată și să solicite sursa oficială, nu să creeze o valoare implicită prezentată drept certitudine.
